import React, { Component } from "react";
const axios = require("axios");

export default class editJournal extends Component {
	constructor(props) {
		super(props);

		// get params from href and extract journalId
		let params = window.location.href.match(/\/editJournal\?.+/);
		if (params) {
			params = params[0].slice(13);
		} else {
			params = "";
		}
		const journalId = new URLSearchParams(params).get("journalId");
		this.journalId = journalId || undefined;
		this.onSubmit = this.onSubmit.bind(this);
		this.onFileChange = this.onFileChange.bind(this);
		this.onTitleChange = this.onTitleChange.bind(this);
		this.onContentChange = this.onContentChange.bind(this);
		this.server = props.server;

		this.state = {
			title: "",
			content: "",
			selectedFiles: undefined,
			successFlag: 0,
			errorMsg: undefined,
			authenticated: false,
			profileImg: "/img/default_profileImg.png",
			background: "/img/default.jpg",
		};
	}

	onTitleChange = (e) => {
		this.setState({
			title: e.target.value,
		});
	};

	onContentChange = (e) => {
		this.setState({
			content: e.target.value,
		});
	};

	onFileChange = (e) => {
		console.log(e.target.files);
		// Update the state
		this.setState({ selectedFiles: e.target.files[0] });
	};

	onSubmit = (e) => {
		e.preventDefault();

		const formdata = new FormData();
		formdata.append("title", this.state.title);
		formdata.append("content", this.state.content);
		formdata.append("selectedFiles", this.state.selectedFiles);
		formdata.append("dateCreated", new Date().toString());
		formdata.append("journalId", this.journalId);

		axios(`${this.server}/editJournal`, {
			method: "POST",
			headers: {
				"Content-Type": "multipart/form-data",
			},
			data: formdata,
			withCredentials: true,
		})
			.then((res) => {
				if (res.data.success) {
					window.location = res.data.message;
				} else {
					this.setState({
						successFlag: 1,
						errorMsg: res.data.message,
					});
				}
			})
			.catch((err) => {
				console.log(`Oops, an error occurred\n${err}`);
				this.setState({
					successFlag: 1,
					errorMsg: err,
				});
			});
	};

	componentDidMount() {
		axios(`${this.server}/auth`, {
			method: "GET",
			withCredentials: true,
		}).then((res) => {
			if (!res.data.success) {
				window.location = res.data.message;
			} else {
				this.setState({
					authenticated: true,
				});

				axios(`${this.server}/getJournal/${this.journalId}`, {
					method: "GET",
					withCredentials: true,
				})
					.then((res) => {
						if (!res.data.success) {
							window.location = res.data.errorMsg;
						} else {
							this.setState(
								{
									title: res.data.journal.title,
									content: res.data.journal.content,
									selectedFiles: res.data.journal.files[0],
									profileImg:
										res.data.profileImg ||
										"/img/default_profileImg.png",
									background:
										res.data.background ||
										"/img/default.jpg",
								},
								() => {
									document.body.style.backgroundImage = `linear-gradient(rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2)), url(${this.server}${this.state.background})`;
									document.body.style.backgroundRepeat =
										"no-repeat";
									document.body.style.backgroundAttachment =
										"fixed";
									document.body.style.backgroundSize =
										"cover";
								}
							);
						}
					})
					.catch((err) => {
						console.log(err);
						window.location = "/home";
					});
			}
		});
	}

	componentWillUnmount() {
		document.body.style.backgroundImage = null;
		document.body.style.backgroundRepeat = null;
		document.body.style.backgroundAttachment = null;
		document.body.style.backgroundSize = null;
	}

	render() {
		let file = undefined;
		if (this.state.selectedFiles) {
			file = this.state.selectedFiles.name || this.state.selectedFiles;
		} else {
			file = "N/A";
		}

		return (
			<>
				<div className="row">
					<div className="col-3">
						<div
							className="card"
							style={{
								width: "80%",
								borderRadius: "12px",
								overflow: "hidden",
							}}
						>
							<img
								className="card-img-top"
								src={`${this.server}${this.state.profileImg}`}
								alt="Card image cap"
								style={{
									width: "120px",
									height: "auto",
									margin: "auto",
									paddingTop: "20px",
								}}
							></img>
							<div className="card-body">
								<h5 className="card-title">
									{this.state.username}
								</h5>
								<p className="card-text">
									Some quick example text to build on the card
									title and make up the bulk of the card's
									content.
								</p>
								<a href="/home" className="btn btn-primary">
									Home
								</a>
							</div>
						</div>
					</div>
					<div className="col-9">
						<div
							className="card"
							style={{
								borderRadius: "12px",
								overflow: "hidden",
							}}
						>
							<div className="card-body">
								<h1
									className="card-title text-center"
									style={{ fontWeight: "bold" }}
								>
									Edit Journal
								</h1>
								<br></br>
								<br></br>

								{this.state.successFlag === 1 && (
									<p className="card-text">
										{" "}
										{this.state.errorMsg}{" "}
									</p>
								)}
								<form
									onSubmit={this.onSubmit}
									encType="multipart/form-data"
								>
									<div className="input-group mb-3">
										<div className="input-group-prepend">
											<span className="input-group-text">
												Title
											</span>
										</div>
										<input
											required
											type="text"
											className="form-control"
											placeholder="Title here..."
											value={this.state.title}
											onChange={this.onTitleChange}
										></input>
									</div>

									<div className="input-group">
										<span className="input-group-text">
											Body
										</span>
										<textarea
											required
											type="text"
											className="form-control"
											placeholder="Content here..."
											value={this.state.content}
											onChange={this.onContentChange}
										></textarea>
									</div>

									<br></br>

									<div className="mb-3">
										<label className="form-label">
											<b>Files Uploaded</b>
										</label>
										<br></br>
										<label className="form-label">
											<em>&ensp;{file}</em>
										</label>
										<input
											className="form-control"
											type="file"
											id="formFileMultiple"
											onChange={this.onFileChange}
										></input>
									</div>
									<br></br>
									<div className="col-md-12 text-center">
										<button
											type="submit"
											className="btn btn-primary text-center"
											style={{ textAlign: "center" }}
										>
											SUBMIT
										</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</>
		);
	}
}

import React, { Component } from "react";
const axios = require("axios");

export default class addJournal extends Component {
	constructor(props) {
		super(props);

		this.onSubmit = this.onSubmit.bind(this);
		this.onFileChange = this.onFileChange.bind(this);
		this.server = props.server;

		this.state = {
			title: "",
			content: "",
			selectedFiles: null,
			successFlag: 0,
			errorMsg: undefined,
			authenticated: false,
			profileImg: "/img/default_profileImg.png",
			background: "/img/default.jpg",
		};
	}

	onFileChange = (e) => {
		console.log(e.target.files);
		// Update the state
		this.setState({ selectedFiles: e.target.files[0] });
	};

	onSubmit = (e) => {
		e.preventDefault();

		const formdata = new FormData();
		formdata.append("selectedFiles", this.state.selectedFiles);

		axios(`${this.server}/addBackground`, {
			method: "POST",
			headers: {
				"Content-Type": "multipart/form-data",
			},
			data: formdata,
			withCredentials: true,
		})
			.then((res) => {
				if (res.data.success) {
					window.location = res.data.message;
				} else {
					this.setState({
						successFlag: 1,
						errorMsg: res.data.message,
					});
				}
			})
			.catch((err) => {
				console.log(`Oops, an error occurred\n${err}`);
				this.setState({
					successFlag: 1,
					errorMsg: err,
				});
			});
	};

	componentDidMount() {
		axios(`${this.server}/auth`, {
			method: "GET",
			withCredentials: true,
		}).then((res) => {
			if (!res.data.success) {
				window.location = res.data.message;
			} else {
				this.setState(
					{
						authenticated: true,
						profileImg:
							res.data.profileImg ||
							"/img/default_profileImg.png",
						background: res.data.background || "/img/default.jpg",
						username: res.data.username,
					},
					() => {
						document.body.style.backgroundImage = `linear-gradient(rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2)), url(${this.server}${this.state.background})`;
						document.body.style.backgroundRepeat = "no-repeat";
						document.body.style.backgroundAttachment = "fixed";
						document.body.style.backgroundSize = "cover";
					}
				);
			}
		});
	}

	componentWillUnmount() {
		document.body.style.backgroundImage = null;
		document.body.style.backgroundRepeat = null;
		document.body.style.backgroundAttachment = null;
		document.body.style.backgroundSize = null;
	}

	render() {
		return (
			<>
				<div
					className="container"
					style={{ width: "60%", alignItems: "center" }}
				>
					<div
						className="card"
						style={{ borderRadius: "12px", overflow: "hidden" }}
					>
						<div className="card-body">
							<h1
								className="text-center"
								style={{ fontWeight: "bold" }}
							>
								Customize Background
							</h1>
							<br></br>
							<br></br>
							{this.state.successFlag === 1 && (
								<p> {this.state.errorMsg} </p>
							)}
							<form
								onSubmit={this.onSubmit}
								encType="multipart/form-data"
							>
								<div className="mb-3">
									<label className="form-label">
										Upload Your Background
									</label>
									<input
										className="form-control"
										type="file"
										id="formFileMultiple"
										onChange={this.onFileChange}
									></input>
								</div>
								<br></br>
								<div className="col-md-12 text-center">
									<button
										type="submit"
										className="btn btn-primary text-center"
										style={{ textAlign: "center" }}
									>
										SUBMIT
									</button>
								</div>
							</form>
						</div>
					</div>
					<br></br>
					<br></br>
					<br></br>
					<br></br>
				</div>
			</>
		);
	}
}

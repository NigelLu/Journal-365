import React, { Component } from 'react';

export default class Welcome extends Component {
    constructor(props) {
        super(props);
    }
    
    render() {
        return (
            <div>
                <h1>Journal 365,</h1>
                <h2>where the journey begins...</h2>
            </div>
        );
    }
}
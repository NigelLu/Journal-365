import React, { Component } from "react";
const axios = require("axios");

export default class Home extends Component {
	constructor(props) {
		super(props);

		this.DATE_OPTIONS = {
			weekday: "short",
			year: "numeric",
			month: "short",
			day: "numeric",
		};

		this.server = props.server;
		this.onEdit = this.onEdit.bind(this);
		this.state = {
			authenticated: false,
			journals: [],
			errorMsg: "",
			profileImg: "/img/default_profileImg.png",
			background: "/img/default.jpg",
			username: "Default User",
		};
	}

	onEdit(e) {
		window.location = `/editJournal?journalId=${e.target.value}`;
	}

	onView(e) {
		window.location = `/viewJournal?journalId=${e.target.value}`;
	}

	componentDidMount() {
		axios(`${this.server}/auth`, {
			method: "GET",
			withCredentials: true,
		})
			.then((res) => {
				if (!res.data.success) {
					window.location = res.data.message;
				} else {
					this.setState({
						authenticated: true,
					});

					axios(`${this.server}/home`, {
						method: "GET",
						withCredentials: true,
					})
						.then((res) => {
							this.setState(
								{
									journals: res.data.journals,
									profileImg:
										res.data.profileImg ||
										"/img/default_profileImg.png",
									background:
										res.data.background ||
										"/img/default.jpg",
								},
								() => {
									document.body.style.backgroundImage = `linear-gradient(rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2)),url(${this.server}${this.state.background})`;
									document.body.style.backgroundRepeat =
										"no-repeat";
									document.body.style.backgroundAttachment =
										"fixed";
									document.body.style.backgroundSize =
										"cover";
								}
							);
						})
						.catch((err) => {
							console.log(`Oops, an error occurred\n${err}`);
							this.setState(
								{
									errorMsg: err,
									profileImg: "/img/default_profileImg.png",
									background: "/img/default.jpg",
								},
								() => {
									document.body.style.backgroundImage = `linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url(${this.server}${this.state.background})`;
									document.body.style.backgroundRepeat =
										"no-repeat";
									document.body.style.backgroundAttachment =
										"fixed";
									document.body.style.backgroundSize =
										"cover";
								}
							);
						});
				}
			})
			.catch((err) => {
				console.log(`Oops, an error occurred\n${err}`);
				window.location = "/login";
			});
	}

	componentWillUnmount() {
		document.body.style.backgroundImage = null;
		document.body.style.backgroundRepeat = null;
		document.body.style.backgroundAttachment = null;
		document.body.style.backgroundSize = null;
	}

	render() {
		return (
			<>
				<div className="row">
					<div className="col-3">
						<div
							className="card text-white bg-dark border-0"
							style={{
								width: "80%",
								borderRadius: "12px",
								overflow: "hidden",
							}}
						>
							<img
								src={`${this.server}/img/notebook.jpg`}
								className="card-img-top"
								alt="Add Journal"
							></img>
							<div className="card-body">
								<h5 className="card-title">New Journal</h5>
								<p className="card-text">
									Those golden old days...
								</p>
								<a
									href="/addJournal"
									className="btn btn-primary stretched-link"
								>
									Create
								</a>
							</div>
						</div>
						<br></br>
						<br></br>
						<br></br>
						<br></br>
						<div
							className="card text-white bg-dark border-0"
							style={{
								width: "80%",
								borderRadius: "12px",
								overflow: "hidden",
							}}
						>
							<img
								src={`${this.server}/img/blog.jpg`}
								className="card-img-top"
								alt="Add Journal"
							></img>
							<div className="card-body">
								<h5 className="card-title">
									Change Background
								</h5>
								<p className="card-text">
									Show us the style of your own...
								</p>
								<a
									href="/addBackground"
									className="btn btn-primary stretched-link"
								>
									Customize
								</a>
							</div>
						</div>
						<br></br>
						<br></br>
						<br></br>
						<br></br>
					</div>
					<div className="col-9">
						{this.state.errorMsg !== "" && (
							<p> {this.state.errorMsg} </p>
						)}
						<table
							className="table table-dark table-striped table-hover"
							style={{ borderRadius: "12px", overflow: "hidden" }}
						>
							<thead>
								<tr>
									<th scope="col" className="text-center">
										#
									</th>
									<th scope="col">Title</th>
									<th scope="col">Content</th>
									<th scope="col">Files</th>
									<th scope="col">Date</th>
									<th
										scope="col"
										className="col-2 text-center"
									>
										Action
									</th>
								</tr>
							</thead>
							<tbody>
								{this.state.journals.map((journal, index) => {
									return (
										<tr key={`${index}`}>
											<th scope="row">{index}</th>
											<td>{journal.title}</td>
											<td>
												{journal.content.slice(0, 25) +
													"..."}
											</td>
											<td>
												{journal.files.length !== 0
													? journal.files[0]
													: "------"}
											</td>
											<td>
												{new Date(
													journal.dateCreated
												).toLocaleDateString(
													"en-US",
													this.DATE_OPTIONS
												)}
											</td>
											<td>
												<button
													type="button"
													className="btn btn-primary"
													value={journal._id}
													onClick={this.onEdit}
												>
													EDIT
												</button>
												&nbsp;&nbsp;&nbsp;&nbsp;
												<button
													type="button"
													className="btn btn-primary"
													value={journal._id}
													onClick={this.onView}
												>
													View
												</button>
											</td>
										</tr>
									);
								})}
							</tbody>
						</table>
						<br></br>
						<br></br>
						<br></br>
						<br></br>
					</div>
				</div>
			</>
		);
	}
}

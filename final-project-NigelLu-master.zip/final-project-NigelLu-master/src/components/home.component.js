import React, { Component } from "react";
const axios = require("axios");

export default class Home extends Component {
	constructor(props) {
		super(props);

		this.server = props.server;
		this.state = {
			authenticated: false,
			journals: [],
			errorMsg: "",
		};
	}

	componentDidMount() {
		axios(`${this.server}/auth`, {
			method: "GET",
			withCredentials: true,
		}).then((res) => {
			if (!res.data.success) {
				window.location = res.data.message;
			} else {
				this.setState({
					authenticated: true,
				});
			}
		}).catch((err) => {
			console.log(`Oops, an error occurred\n${err}`);
			window.location = '/login';
		});

		axios(`${this.server}/home`, {
			method: "GET",
			withCredentials: true,
		}).then((res) => {
			if (res.data.success) {
				this.setState({
					journals: res.data.journals,
				});
			} else {
				this.setState({
					errorMsg: res.data.errorMsg,
				});
			}
		}).catch((err) => {
			console.log(`Oops, an error occurred\n${err}`);
			this.setState({
				errorMsg: err,
			});
		});
	}

	render() {

		return (
			<>
				<div className="row">
					<div className="col-3">
						<div className="card" style={{ width: "18rem" }}>
							<img
								src={`${this.server}/img/notebook.jpg`}
								className="card-img-top"
								alt="Add Journal"
							></img>
							<div className="card-body">
								<h5 className="card-title">New Journal</h5>
								<p className="card-text">
									Those golden old days...
								</p>
								<a
									href="/addJournal"
									className="btn btn-primary stretched-link"
								>
									Create
								</a>
							</div>
						</div>
					</div>
					<div className="col-9">
						{this.state.errorMsg !== "" && (
							<p> {this.state.errorMsg} </p>
						)}

						<table className="table table-striped">
							<thead>
								<tr>
									<th scope="col">#</th>
									<th scope="col">Title</th>
									<th scope="col" className="col-lg-4">
										Content
									</th>
									<th scope="col">Files</th>
									<th scope="col">Date</th>
								</tr>
							</thead>
							<tbody>
								{this.state.journals.map((journal, index) => {
									return (
										<tr key={`${index}`}>
											<th scope="row">{index}</th>
											<td>{journal.title}</td>
											<td>{journal.content}</td>
											<td>{journal.files ? journal.files[0] : ""}</td>
											<td>{journal.dateCreated}</td>
										</tr>
									);
								})}
							</tbody>
						</table>
					</div>
				</div>
			</>
		);
	}
}

import React, { Component } from "react";
const axios = require("axios");

export default class addJournal extends Component {
	constructor(props) {
		super(props);

		this.onSubmit = this.onSubmit.bind(this);
		this.onFileChange = this.onFileChange.bind(this);
		this.onTitleChange = this.onTitleChange.bind(this);
		this.onContentChange = this.onContentChange.bind(this);
		this.server = props.server;

		this.state = {
			title: "",
			content: "",
			selectedFiles: null,
			successFlag: 0,
			errorMsg: undefined,
		};
	}

	onTitleChange = (e) => {
		this.setState({
			title: e.target.value,
		});
	};

	onContentChange = (e) => {
		this.setState({
			content: e.target.value,
		});
	};

	onFileChange = (e) => {
		console.log(e.target.files);
		// Update the state
		this.setState({ selectedFiles: e.target.files[0] });
	};

	onSubmit = (e) => {
		e.preventDefault();

		const formdata = new FormData();
		formdata.append("title", this.state.title);
		formdata.append("content", this.state.content);
		formdata.append("selectedFiles", this.state.selectedFiles);
		formdata.append("dateCreated", new Date().toString());

		axios(`${this.server}/addJournal`, {
			method: "POST",
			headers: {
				"Content-Type": "multipart/form-data",
			},
			data: formdata,
			withCredentials: true,
		})
			.then((res) => {
				if (res.data.success) {
					window.location = res.data.message;
				} else {
					this.setState({
						successFlag: 1,
						errorMsg: res.data.message,
					});
				}
			})
			.catch((err) => {
				console.log(`Oops, an error occurred\n${err}`);
				this.setState({
					successFlag: 1,
					errorMsg: err,
				});
			});
	};

	render() {
		return (
			<>
				<h1 className="text-center" style={{ fontWeight: "bold" }}>
					New Journal
				</h1>
				<br></br>
				<br></br>
				{this.state.successFlag === 1 && <p> {this.state.errorMsg} </p>}
				<form onSubmit={this.onSubmit} encType="multipart/form-data">
					<div className="input-group mb-3">
						<div className="input-group-prepend">
							<span className="input-group-text">Title</span>
						</div>
						<input
							required
							type="text"
							className="form-control"
							placeholder="Title here..."
							value={this.state.title}
							onChange={this.onTitleChange}
						></input>
					</div>

					<div className="input-group">
						<span className="input-group-text">Body</span>
						<textarea
							required
							type="text"
							className="form-control"
							placeholder="Content here..."
							value={this.state.content}
							onChange={this.onContentChange}
						></textarea>
					</div>

					<br></br>

					<div className="mb-3">
						<label className="form-label">Upload Files</label>
						<input
							className="form-control"
							type="file"
							id="formFileMultiple"
							onChange={this.onFileChange}
						></input>
					</div>
					<br></br>
					<div className="col-md-12 text-center">
						<button
							type="submit"
							className="btn btn-primary text-center"
							style={{ textAlign: "center" }}
						>
							SUBMIT
						</button>
					</div>
				</form>
			</>
		);
	}
}

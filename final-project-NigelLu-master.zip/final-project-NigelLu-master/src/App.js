import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import Navbar from "./components/navbar.component";
import Welcome from "./components/welcome.component";
import Register from "./components/register.component";
import Home from "./components/home.component";
import Login from "./components/login.component";
import AddJournal from "./components/addJournal.component";

function App() {
	return (
		<Router>
            <Navbar />
			<div className="container">
				<br />
				<Routes>
					<Route path="/" exact element={<Welcome server={process.env.REACT_APP_SERVER}/>} />
                    <Route path="/register" element={<Register server={process.env.REACT_APP_SERVER}/>} />
					<Route path="/home" element={<Home server={process.env.REACT_APP_SERVER}/>} />
					<Route path="/login" element={<Login server={process.env.REACT_APP_SERVER}/>} />
					<Route path="/addJournal" element={<AddJournal server={process.env.REACT_APP_SERVER}/>} />
				</Routes>
			</div>
		</Router>
	);
}

export default App;

# Journal *365*
### Spring 2022 CSCI-UA 0467

---

## Overview

### A web application for writing diaries

Functionality
- User register & login
  - authentication & password hashing
- After login, one can
	- see one's own journals
	- edit one's own journals
	- create new journals, including text & uploading files/images
	- set/change background for one's homepage
	- set/change one's profile image
---

## Data Model

The application will store Users and Journals

* users can have multiple journals (by embedding), but only one background image and profile image
* each journal will have text, attached_files, and date_created

An Example User:

```javascript
{
  username: "Nigel",
  pwd: // a password hash,
  journals: // an array of embedded Journal Schemas,
  background: // uploaded background image, retrieved via API,
  profileImg: // self-defined profile image, retrieved via API,
}
```

An Example of embedded Journal:

```javascript
{
  title: // journal title,
  content: // journal content,
  files: // uploaded related files, retrieved via API,
  dateCreated: // timestamp
}
```


## [Link to Commented First Draft Schema](db.js) 

## Wireframes

Pages included in the PDF
- Welcome Page
- Register Page
- Login Page
- User Home Page
- Editor Page
- Personalize Page

[wireframes pdf link](documentation/wireframes.pdf)

## Site map
![Site Map](documentation/site-map.jpg)

## User Stories or Use Cases

1. as non-registered user, I can visit the home page/register as a new user to this site.
2. as a user, I can log in to the site
3. as a user, I can create a new journal (title, content, and files)
4. as a user, I can view all of the journals I created in the past
5. as a user, I can edit the journals I created in the past
6. as a user, I can delete any journal I created

## Research Topics
### 14 points total

* (3 points) Add Unit Tests
    * I'm going to be using Mocha for doing at least 4 unit tests
    * I will add the [link](/) here once I finish writing the test codes
    * I will put the screenshot ![here](/)
* (2 points) Perform client side form validation using a JavaScript library
    * I will be using a 3rd-party JavaScript library for doing form validation before submitting it to the server
* (4 points) React JS
    * I will be using React JS as my front-end library. 
    * As this is a library that takes much effort to master, I will assign to this 5 points
* (2 points) Bootstrap CSS Framework
    * I will be consistently using Bootstrap as my CSS library throughout the site
* (1 points) File Upload with Multer
    * I will be using third-party package named *Multer* for managing file uploads
* (2 points) Axios HTTP Client
    * I will be using Axios for making HTTP requests
    * As this adds some work for hard coding form headers and figuring out miscellaneous HTTP request details, I will assing 2 points (unlike using HTML form, which just needs to set attributes like actoin, method, etc.)
* (0 point) Miscellaneous 
    * I will be using Dotenv to manage all my environment variables for project-wide usage

14 points total out of 8 required points 


## [Link to Initial Main Project File](app.js) 

## Annotations / References Used

1. [MERN Full Stack Tutorial](https://www.youtube.com/watch?v=ktjafK4SgWM)
2. [React JS Documentation](https://reactjs.org/docs/getting-started.html)
3. [Passport Documentation](https://www.passportjs.org/docs/)


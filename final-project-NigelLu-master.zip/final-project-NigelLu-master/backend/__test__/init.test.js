const supertest = require('supertest');

// This is an initial test to check if jest library is working normally
it(`Testing to see if Jest works`, () => {
    expect(1).toBe(1);
});
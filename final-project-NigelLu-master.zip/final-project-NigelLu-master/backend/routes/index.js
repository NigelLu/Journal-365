const express = require("express"),
	router = express.Router(),
	passport = require("passport"),
	mongoose = require("mongoose"),
	User = mongoose.model("User");
Journal = mongoose.model("Journal");
multer = require("multer");

require("dotenv").config();

const storage = multer.diskStorage({
	destination: function (req, file, cb) {
		cb(null, process.env.UPLOAD);
	},
	filename: function (req, file, cb) {
		const uniqueSuffix = Math.round(Math.random() * 1e9);
		cb(null, uniqueSuffix + '-' + file.originalname);
	},
});

const upload = multer({ storage: storage });

// #region old APIs
// router.get('/logout', (req, res) => {
//   req.logout();
//   res.redirect('/');
// });

// router.get('/', (req, res) =>  {
//   res.render('home');
// });

// router.get('/login', (req, res) =>  {
//   res.render('login');
// });

// router.get('/register', (req, res) =>  {
//   res.render('register');
// });
// #endregion

// #region authentication, register, and login
router.post("/register", (req, res) => {
	User.register(
		new User({ username: req.body.username }),
		req.body.password,
		(err, user) => {
			if (err) {
				res.json({
					success: false,
					message: `${err}`,
				});
			} else {
				console.log(`Successfully save user\n${JSON.stringify(user)}`);
				passport.authenticate("local")(req, res, function () {
					res.json({
						success: true,
						message: "/home",
					});
				});
			}
		}
	);
});

router.post("/login", (req, res, next) => {
	passport.authenticate("local", (err, user) => {
		if (user) {
			req.logIn(user, (err) => {
				res.json({
					username: user.username,
					journals: user.journals,
					background: user.background,
					profileImg: user.profileImg,
					message: "/home",
					success: true,
				});
			});
		} else {
			res.json({
				success: false,
				message: `${err}`,
			});
		}
	})(req, res, next);
});

router.get("/auth", (req, res) => {
	if (req.isAuthenticated()) {
		res.json({
			success: true,
			message: "user authenticated.",
		});
	} else {
		res.json({
			success: false,
			message: "/login",
		});
	}
});
// #endregion

// #region journal CRUD
// , upload.single("selectedFiles")
// const reqFiles = [];
// 		console.log(req.files);
// 		for (let i = 0; i < req.files.length; i++) {
// 			req.Files.push(req.files[i].filename);
// 		}
router.post("/addJournal", upload.single("selectedFiles"), async (req, res) => {
	try {
		const reqFiles = [];
		reqFiles.push(req.file.filename);
		const newJournal = new Journal({
			title: req.body.title,
			content: req.body.content,
			files: reqFiles,
			dateCreated: req.body.dateCreated,
		});
		let savedJournal = await newJournal.save(); //when fail its goes to catch
		console.log(`Journale saved\n${savedJournal}`); //when success it print.
		res.json({
			success: true,
			message: "/home",
		});
	} catch (err) {
		console.log("err" + err);
		res.status(500).json({
			success: false,
			message: `${err}`,
		});
	}
});

router.get("/home", (req, res) => {
	Journal.find({}, (err, docs) => {
		if (!err) {
			res.json({
				success: true,
				journals: docs,
				errorMsg: undefined,
			});
		} else {
			res.json({
				success: false,
				journals: undefined,
				errorMsg: err,
			});
		}
	});
});
// #endregion

module.exports = router;
